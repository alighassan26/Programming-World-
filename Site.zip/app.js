import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getFirestore, collection, addDoc } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-firestore.js";

// مفاتيح Firebase عندك
const firebaseConfig = {
  apiKey: "AIzaSyATbKjOj2MZwkLFO2xE5_7kiykIeDGFHd8",
  authDomain: "programming-world-ali.firebaseapp.com",
  projectId: "programming-world-ali",
  storageBucket: "programming-world-ali.appspot.com",
  messagingSenderId: "1097568580678",
  appId: "1:1097568580678:web:308685f5aec51515a64647"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// أزرار اللغات (إضافة مثال بسيط)
document.querySelectorAll(".lang-btn").forEach(btn => {
  btn.onclick = () => {
    const lang = btn.dataset.lang;
    let info = "";
    if (lang === "Python") {
      info = `Python: لغة سهلة وتستخدم في الذكاء الاصطناعي والويب.`;
    } else if (lang === "JavaScript") {
      info = `JavaScript: لغة الويب الأساسية لتطوير صفحات تفاعلية.`;
    } else if (lang === "Java") {
      info = `Java: لغة قوية تُستخدم في تطبيقات الأندرويد والخوادم.`;
    }
    document.getElementById("languageInfo").innerText = info;
  };
});

// إرسال طلب مشروع إلى Firestore
document.getElementById("projectForm").onsubmit = async (e) => {
  e.preventDefault();
  const type = document.getElementById("projectType").value;
  const details = document.getElementById("projectDetails").value;
  
  try {
    await addDoc(collection(db, "projectRequests"), {
      type,
      details,
      timestamp: new Date()
    });
    alert("✅ تم إرسال طلب المشروع!");
    e.target.reset();
  } catch (error) {
    alert("❌ حدث خطأ، حاول مرة أخرى.");
    console.error(error);
  }
};

// إرسال رسالة تواصل إلى Firestore
document.getElementById("contactForm").onsubmit = async (e) => {
  e.preventDefault();
  const name = document.getElementById("contactName").value;
  const email = document.getElementById("contactEmail").value;
  const message = document.getElementById("contactMessage").value;
  
  try {
    await addDoc(collection(db, "contactMessages"), {
      name,
      email,
      message,
      timestamp: new Date()
    });
    alert("📧 تم إرسال رسالتك!");
    e.target.reset();
  } catch (error) {
    alert("❌ حدث خطأ، حاول مرة أخرى.");
    console.error(error);
  }
};